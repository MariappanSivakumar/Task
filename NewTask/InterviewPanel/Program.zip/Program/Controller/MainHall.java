package Controller;

import View.Interview;

public class MainHall {

    java.util.Queue<String> persons = new java.util.LinkedList();

    public String getName() {
        String username = "";
        try {
            username = ((new java.io.BufferedReader(new java.io.InputStreamReader(System.in))).readLine());
        } catch (java.io.IOException e) {
        }
        return username;
    }

    public void MoveNextPerson() {
       if(persons.size()!=0)
       {
           System.out.println("Interview Process Is Completed : "+persons.poll());
       }else 
       {
           System.out.println("Persons are Empty");
       }
    }

    public java.util.Queue<String> Insert(java.util.Queue<String> TotalPersons) {
        TotalPersons.add(getName());
        return TotalPersons;
    }

    public void Process() {
        int number = 0;
        while ((number = new Interview().Display()) != 4) {
            if (number == 1) {
                
                if(persons.size() != 5)
                {
                    System.out.print("ENTER THE NAME: ");
                    persons = Insert(persons);
                }
                else System.out.println("Main Hall is Full Please Be Wait until Process is completed");
                System.out.println();
            } else if (number == 2) {
                MoveNextPerson();
            } else {
                System.out.println(persons);
            }
        }
    }
}
