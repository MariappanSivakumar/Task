package View;

public class Interview {

    public int getIntegerValue() {
        int number = 0;
        while (number != 4 && number != 3 && number != 2 && number != 1) {
            try {
                System.out.print("Enter the Valid Option > ");
                number = Integer.parseInt((new java.io.BufferedReader(new java.io.InputStreamReader(System.in))).readLine());
                System.out.println();
            } catch (java.io.IOException e) {
            } catch (NumberFormatException e) {
                number = 5;
            }
        }
        return number;
    }

    public int Display() {
        System.out.println("===============================================================");
        System.out.println("1. Insert  ");
        System.out.println("2. Move  ");
        System.out.println("3. Display Current Persons");
        System.out.println("4. Exit");
        System.out.println("===============================================================");

        return getIntegerValue();
    }
}