package interviewpanel;

import Controller.MainHall;
import View.Interview;

public class InterviewPanel {

    public static void main(String[] args) {
        new MainHall().Process();
    }

}
